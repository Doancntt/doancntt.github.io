package ca.dmoj.java;

public class BigDecimalDisallowedException extends RuntimeException {
}
