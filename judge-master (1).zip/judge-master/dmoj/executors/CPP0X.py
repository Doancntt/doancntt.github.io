from dmoj.executors.CPP11 import Executor as CPP11Executor


class Executor(CPP11Executor):
    std = 'c++0x'
    name = 'CPP0X'
