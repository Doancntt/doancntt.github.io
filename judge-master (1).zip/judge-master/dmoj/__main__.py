from dmoj.judge import main

if __name__ == '__main__':
    import sys
    sys.argv[0] = 'python -m dmoj'
    main()
