def check(process_output, judge_output, **kwargs):
    return judge_output == process_output
