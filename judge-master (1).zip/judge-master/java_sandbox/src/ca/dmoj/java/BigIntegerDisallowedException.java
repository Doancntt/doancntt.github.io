package ca.dmoj.java;

public class BigIntegerDisallowedException extends RuntimeException {
}
