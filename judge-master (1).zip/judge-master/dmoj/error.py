class CompileError(Exception):
    pass


class InternalError(Exception):
    pass
