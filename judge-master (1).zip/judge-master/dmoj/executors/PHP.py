from .php_executor import PHPExecutor
from dmoj.judgeenv import env


class Executor(PHPExecutor):
    name = 'PHP'
    command = 'php'
    command_paths = ['php5', 'php']

    fs = PHPExecutor.fs
    if 'phpconfdir' in env['runtime']:
        fs += [env['runtime']['phpconfdir']]
